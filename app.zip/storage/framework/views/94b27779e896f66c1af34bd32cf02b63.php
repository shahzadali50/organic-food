  <!-- JavaScript Libraries -->
  <script src="https://code.jquery.com/jquery-3.4.1.min.js"></script>
  <?php echo $__env->make('flashy::message', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0/dist/js/bootstrap.bundle.min.js"></script>
  <script src="<?php echo e(url('assets/lib/wow/wow.min.js')); ?>"></script>
  <script src="<?php echo e(url('assets/lib/easing/easing.min.js')); ?>"></script>
  <script src="<?php echo e(url('assets/lib/waypoints/waypoints.min.js')); ?>"></script>
  <script src="<?php echo e(url('assets/lib/owlcarousel/owl.carousel.min.js')); ?>"></script>

  <!-- Template Javascript -->
  <script src="<?php echo e(url('assets/js/main.js')); ?>"></script>

  <?php echo $__env->yieldPushContent('addToCartAjax'); ?>




<?php /**PATH D:\BS.IT Material\my practice work\laravel\organic-food\resources\views/components/foot.blade.php ENDPATH**/ ?>