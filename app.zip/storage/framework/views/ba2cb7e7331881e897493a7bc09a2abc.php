<?php $__env->startSection('content'); ?>



<!-- Product Start -->
<div class="container-xxl py-5">
    <div class="row justify-content-center">
        <div class="col-10">
            <div class="row">
                <div class="col-12" style="margin-top: 200px;">
                    <div class="card-header border py-5 text-center">
                        <h3 class="text-success">Thank You Soo Much ✅</h3>
                        <h5>Order will be Generated Successfully.</h5>

                    </div>
                </div>
            </div>
        </div>
    </div>

</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\BS.IT Material\my practice work\laravel\organic-food\resources\views/order-message.blade.php ENDPATH**/ ?>