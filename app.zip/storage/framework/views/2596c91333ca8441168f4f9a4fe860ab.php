<?php $__env->startSection('content'); ?>
 <!-- Page Header Start -->
 <div class="container-fluid page-header wow fadeIn" data-wow-delay="0.1s">
    <div class="container">
        <h1 class="display-3 mb-3 animated slideInDown">Testimonial</h1>
        <nav aria-label="breadcrumb animated slideInDown">
            <ol class="breadcrumb mb-0">
                <li class="breadcrumb-item"><a class="text-body" href="<?php echo e(route('home')); ?>">Home</a></li>
                <li class="breadcrumb-item"><a class="text-body" href="#">Pages</a></li>
                <li class="breadcrumb-item text-dark active" aria-current="page">Testimonial</li>
            </ol>
        </nav>
    </div>
</div>
<!-- Page Header End -->


<!-- Testimonial Start -->
<?php if (isset($component)) { $__componentOriginal0636a061207948776bdafdc58bc2a722 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0636a061207948776bdafdc58bc2a722 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.client-message','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('client-message'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0636a061207948776bdafdc58bc2a722)): ?>
<?php $attributes = $__attributesOriginal0636a061207948776bdafdc58bc2a722; ?>
<?php unset($__attributesOriginal0636a061207948776bdafdc58bc2a722); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0636a061207948776bdafdc58bc2a722)): ?>
<?php $component = $__componentOriginal0636a061207948776bdafdc58bc2a722; ?>
<?php unset($__componentOriginal0636a061207948776bdafdc58bc2a722); ?>
<?php endif; ?>
<!-- Testimonial End -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\BS.IT Material\my practice work\laravel\organic-food\resources\views/testimonial.blade.php ENDPATH**/ ?>