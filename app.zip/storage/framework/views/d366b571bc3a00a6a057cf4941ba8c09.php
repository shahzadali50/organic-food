 <!-- Navbar Start -->
 <div class="container-fluid fixed-top px-0 wow fadeIn" data-wow-delay="0.1s">
     <div class="top-bar row gx-0 align-items-center d-none d-lg-flex">
         <div class="col-lg-6 px-5 text-start">

             
             <small><i class="fa fa-map-marker-alt me-2"></i>103 Street, TBZ, Sahiwal</small>
             <small class="ms-4"><i class="fa fa-envelope me-2"></i>Email@example.com</small>
         </div>
         <div class="col-lg-6 px-5 text-end">
             <small>Follow us:</small>
             <a class="text-body ms-3" href=""><i class="fab fa-facebook-f"></i></a>
             <a class="text-body ms-3" href=""><i class="fab fa-twitter"></i></a>
             <a class="text-body ms-3" href=""><i class="fab fa-linkedin-in"></i></a>
             <a class="text-body ms-3" href=""><i class="fab fa-instagram"></i></a>
         </div>
     </div>

     <nav class="navbar navbar-expand-lg navbar-light py-lg-0 px-lg-5 wow fadeIn" data-wow-delay="0.1s">
         <a href="<?php echo e(route('home')); ?>" class="navbar-brand ms-4 ms-lg-0">
             <h1 class="fw-bold text-primary m-0">F<span class="text-secondary">OO</span>D</h1>
         </a>
         <button type="button" class="navbar-toggler me-4" data-bs-toggle="collapse" data-bs-target="#navbarCollapse">
             <span class="navbar-toggler-icon"></span>
         </button>
         <div class="collapse navbar-collapse" id="navbarCollapse">
             <div class="navbar-nav ms-auto p-4 p-lg-0">
                 <a href="<?php echo e(route('home')); ?>" class="nav-item nav-link active">Home</a>
                 <a href="<?php echo e(route('about.us')); ?>" class="nav-item nav-link">About Us</a>
                 <a href="<?php echo e(route('products')); ?>" class="nav-item nav-link">Products</a>
                 <div class="nav-item dropdown">
                     <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">Pages</a>
                     <div class="dropdown-menu m-0">

                         <a href="<?php echo e(route('features')); ?>" class="dropdown-item">Our Features</a>
                         <a href="<?php echo e(route('testimonial')); ?>" class="dropdown-item">Testimonial</a>
                         
                         
                     </div>
                 </div>
                 <a href="<?php echo e(route('contact.us')); ?>" class="nav-item nav-link">Contact Us</a>
                 <?php if(Route::has('login')): ?>
                 <?php if(auth()->guard()->check()): ?>

                 <div class="nav-item dropdown">
                     <a href="#" class="nav-link dropdown-toggle" data-bs-toggle="dropdown">
                         <?php echo e(Auth::user()->name); ?></a>
                     <div class="dropdown-menu m-0">
                         
                         <form method="POST" action="<?php echo e(route('logout')); ?>">
                             <?php echo csrf_field(); ?>
                             <a href="<?php echo e(route('logout')); ?>" class="dropdown-item"
                                 onclick="event.preventDefault(); this.closest('form').submit();">Logout</a>
                         </form>
                     </div>
                 </div>
                 

             <?php else: ?>
             <a href="<?php echo e(route('login')); ?>" class="nav-item nav-link">Log in</a>

             <?php if(Route::has('register')): ?>
             <a href="<?php echo e(route('register')); ?>" class="nav-item nav-link">Register</a>
             <?php endif; ?>
             <?php endif; ?>
             
             <?php endif; ?>

         </div>
         <div class="d-none d-lg-flex ms-2">

             <a class="btn-sm-square bg-white rounded-circle ms-3" href="<?php echo e(route('cart')); ?>">

                 <small> <i class="fa fa-shopping-cart text-dark" aria-hidden="true"></i></small>

             </a>
         </div>
 </div>
 </nav>
 </div>
 <!-- Navbar End -->
<?php /**PATH D:\BS.IT Material\my practice work\laravel\organic-food\resources\views/components/header.blade.php ENDPATH**/ ?>