@extends('layouts.app')
@section('content')



<!-- Product Start -->
<div class="container-xxl py-5">
    <div class="row justify-content-center">
        <div class="col-10">
            <div class="row">
                <div class="col-12" style="margin-top: 200px;">
                    <div class="card-header border py-5 text-center">
                        <h3 class="text-success">Thank You Soo Much ✅</h3>
                        <h5>Order will be Generated Successfully.</h5>

                    </div>
                </div>
            </div>
        </div>
    </div>

</div>


@endsection
