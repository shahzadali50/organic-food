<?php $__env->startSection('content'); ?>
    <section style="margin: 60px 0px 0px 0px">
        <div class="container-xxl mt-5 py-6">
            <div class="container">
                <div class="row">
                    <?php if(Session::has('success')): ?>
                        <div class="col-lg-7 col-12 ">
                            <div class="alert alert-success alert-dismissible fade show" role="alert">
                                <?php echo e(Session::get('success')); ?>

                                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                            </div>

                        </div>
                    <?php endif; ?>
                    <?php if(Session::has('error')): ?>
                        <div class="col-lg-7 col-12 ">
                            <div class="alert alert-danger  alert-dismissible fade show" role="alert">
                                <?php echo e(Session::get('error')); ?>

                                <button type="button" class="btn-close" data-bs-dismiss="alert"
                                    aria-label="Close"></button>
                            </div>

                        </div>
                    <?php endif; ?>

                    <?php if(Cart::count() > 0): ?>
                        <div class="col-lg-7 col-12">
                            <table class="table">
                                <thead>
                                    <tr class="bg-info">

                                        <th scope="col">Image</th>
                                        <th scope="col">Items</th>
                                        <th scope="col">Price</th>
                                        <th scope="col">QTY</th>
                                        <th scope="col">Total</th>
                                        <th scope="col">Action</th>
                                    </tr>
                                </thead>
                                <tbody>

                                    <?php $__currentLoopData = $cartContent; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><img width="80" height="80"
                                                    src="<?php echo e(url('storage/' . $item->options[0])); ?>" alt="not-show"></td>
                                            <td><?php echo e($item->name); ?></td>
                                            <td> Rs <?php echo e($item->price); ?>/-</td>
                                            <td class="d-flex" style="width: 180px">
                                                <div>
                                                    <button style="height: 35px;" class="btn btn-success sub"
                                                        data-id="<?php echo e($item->rowId); ?>">
                                                        <i class="fa fa-minus" aria-hidden="true"></i>
                                                    </button>

                                                </div>
                                                <input readonly style="height: 35px;" class="form-control" type="number"
                                                    value="<?php echo e($item->qty); ?>">
                                                <div>

                                                    <button class="btn btn-success add" style="height: 35px;"
                                                        data-id="<?php echo e($item->rowId); ?>">
                                                        <i class="fa fa-plus" aria-hidden="true"></i>
                                                    </button>

                                                </div>
                                            </td>
                                            <td> Rs <?php echo e($item->price * $item->qty); ?>/-</td>
                                            <td>
                                                <button onclick="deleteItem('<?php echo e($item->rowId); ?>')"
                                                    class="btn btn-danger"><i class="fa fa-times"
                                                        aria-hidden="true"></i></button>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                </tbody>
                            </table>
                            <a href="<?php echo e(route('home')); ?>" class="btn  btn-success"> <i
                                    class="fa fa-shopping-cart text-white" aria-hidden="true"></i> Continue shopping</a>


                        </div>
                        <div class="col-lg-5 col-12">
                            <div class="card py-5 px-4"
                                style="border: none;box-shadow: rgba(67, 71, 85, 0.27) 0px 0px 0.25em, rgba(90, 125, 188, 0.05) 0px 0.25em 1em;">
                                <div class="text-center card-header">
                                    <h3 class="text-secondary">Cart Summery</h3>
                                </div>
                                <table class="table">
                                    <thead>
                                        <tr>

                                            <th scope="col">Subtotal</th>
                                            <th scope="col">Rs <?php echo e(Cart::subTotal()); ?>/-</th>

                                        </tr>
                                        <tr>
                                            <th scope="col">Total</th>
                                            <th scope="col">Rs <?php echo e(Cart::subTotal()); ?>/-</th>
                                        </tr>
                                    </thead>

                                </table>
                                <a href="<?php echo e(route('checkout')); ?>" class="btn  btn-success"><i class="fa fa-lock"
                                        aria-hidden="true"></i> Proceed to Checkout</a>
                            </div>
                        </div>
                    <?php else: ?>
                        <div class="col-12">
                            <div class="card ">
                                <div class="card-header py-4">
                                    <h5>Your cart is Empty !</h5>
                                    <a href="<?php echo e(route('home')); ?>" class="btn  btn-success"> <i
                                            class="fa fa-shopping-cart text-white" aria-hidden="true"></i> Continue
                                        shopping</a>

                                </div>
                            </div>
                        </div>
                    <?php endif; ?>

                </div>
            </div>
        </div>

        </div>
    </section>

<?php $__env->stopSection(); ?>
<?php $__env->startPush('addToCartAjax'); ?>
    <script>
        $('.add').click(function() {
            var qtyElement = $(this).parent().prev(); // Qty Input
            var qtyValue = parseInt(qtyElement.val());
            // if (qtyValue < 10) {
            qtyElement.val(qtyValue + 1);
            var rowId = $(this).data('id');
            var newQty = qtyElement.val()
            updateCart(rowId, newQty)
            // }
        });
        $('.sub').click(function() {
            var qtyElement = $(this).parent().next();
            var qtyValue = parseInt(qtyElement.val());
            // if (qtyValue > 1) {
            qtyElement.val(qtyValue - 1);
            var rowId = $(this).data('id');
            var newQty = qtyElement.val()
            updateCart(rowId, newQty)
            // }
        });

        function updateCart(rowId, qty) {
            var csrfToken = "<?php echo e(csrf_token()); ?>";
            $.ajax({
                url: '<?php echo e(route('front.updateCart')); ?>',
                type: 'post',
                data: {
                    rowId: rowId,
                    qty: qty,
                    _token: csrfToken,
                },
                dataType: 'json',
                success: function(response) {
                    if (response.status == true) {
                        window.location.href = "<?php echo e(route('cart')); ?>";
                    } else {

                        Swal.fire({
                            icon: "error",
                            title: "Not Avaible Stock",
                            text: "Something went wrong!",
                            footer: response.message,
                            didClose: function() {
                        location.reload(); // Reload the page after the modal is closed
                    }
                        });
                        // alert(response.message);
                    }
                }
            })
        }

        function deleteItem(rowId) {
            var csrfToken = "<?php echo e(csrf_token()); ?>";
            if (confirm('Are you sure you want to delete')) {
                $.ajax({
                    url: '<?php echo e(route('front.deleteItem.cart')); ?>',
                    type: 'post',
                    data: {
                        rowId: rowId,
                        _token: csrfToken,
                    },
                    dataType: 'json',
                    success: function(response) {
                        if (response.status == true) {
                            window.location.href = "<?php echo e(route('cart')); ?>";
                        } else {
                            alert(response.message);
                        }
                    }
                });
            }
        }
    </script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\BS.IT Material\my practice work\laravel\organic-food\resources\views/cart.blade.php ENDPATH**/ ?>